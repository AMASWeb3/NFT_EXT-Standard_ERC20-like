/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.ao.aoxapp.R;
import com.ao.aoxapp.ui.adapter.MainPagerAdapter;
import com.ao.aoxapp.ui.fragment.ContactsFragment;
import com.ao.aoxapp.ui.fragment.ProfileFragment;
import com.ao.aoxapp.utility.CustomViewPager;
import com.twilio.voice.CallInvite;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends BaseActivity {
    public static MainActivity instance;

    @BindView(R.id.content)
    CustomViewPager contentPager;

    @BindView(R.id.btn_contacts)
    RelativeLayout btn_contacts;
    @BindView(R.id.img_contacts)
    ImageView img_contacts;
    @BindView(R.id.txt_contacts)
    TextView txt_contacts;

    @BindView(R.id.btn_profile)
    RelativeLayout btn_profile;
    @BindView(R.id.img_profile)
    ImageView img_profile;
    @BindView(R.id.txt_profile)
    TextView txt_profile;

    MainPagerAdapter pagerAdapter;
    public ContactsFragment contactsFragment;
    public ProfileFragment profileFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        instance = this;

        initUI();

        CallInvite callInvite = getIntent().getParcelableExtra(VoiceActivity.INCOMING_CALL_INVITE);
        if (callInvite != null) {
            processIncomingCall();
        }
    }

    @Override
    public void onBackPressed() {
        final Dialog dialog = new Dialog(instance);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
        TextView title = (TextView) dialog.findViewById(R.id.txt_title);
        TextView message = (TextView) dialog.findViewById(R.id.txt_message);
        TextView left = (TextView) dialog.findViewById(R.id.btn_left);
        TextView right = (TextView) dialog.findViewById(R.id.btn_right);
        title.setText(getResources().getString(R.string.app_name));
        message.setText("Are you sure you want to exit?");
        left.setText("Ok");
        right.setText("Cancel");
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @Override
    public void onResume() {
        super.onResume();

        instance = this;

        if (contactsFragment != null)
            contactsFragment.setMainActivity(instance);
        if (profileFragment != null)
            profileFragment.setMainActivity(instance);
    }

    private void initUI() {
        pagerAdapter = new MainPagerAdapter(getSupportFragmentManager());
        contactsFragment = new ContactsFragment();
        pagerAdapter.addFragment(contactsFragment);

        profileFragment = new ProfileFragment();
        pagerAdapter.addFragment(profileFragment);

        contentPager.setAdapter(pagerAdapter);
        contentPager.setOffscreenPageLimit(2);

        contentPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}
            @Override
            public void onPageSelected(int position) { resetBottomAndToolBarIcons(); }
            @Override
            public void onPageScrollStateChanged(int state) {}
        });
    }

    private void resetBottomAndToolBarIcons() {
        btn_contacts.setBackgroundColor(getResources().getColor(R.color.white));
        btn_profile.setBackgroundColor(getResources().getColor(R.color.white));

        img_contacts.setImageResource(R.drawable.ic_contacts);
        img_profile.setImageResource(R.drawable.ic_profile);

        txt_contacts.setTextColor(getResources().getColor((R.color.blue)));
        txt_profile.setTextColor(getResources().getColor((R.color.blue)));

        contentPager.setPagingEnabled(false);
    }

    @OnClick(R.id.btn_contacts)
    public void onContacts() {
        contentPager.setCurrentItem(0, true);
        contactsFragment.onResume();
        resetBottomAndToolBarIcons();

        btn_contacts.setBackgroundColor(getResources().getColor(R.color.blue));
        img_contacts.setImageResource(R.drawable.ic_contacts_white);
        txt_contacts.setTextColor(getResources().getColor((R.color.white)));
    }

    @OnClick(R.id.btn_profile)
    public void onProfile() {
        contentPager.setCurrentItem(1, true);
        profileFragment.onResume();
        resetBottomAndToolBarIcons();

        btn_profile.setBackgroundColor(getResources().getColor(R.color.blue));
        img_profile.setImageResource(R.drawable.ic_profile_white);
        txt_profile.setTextColor(getResources().getColor((R.color.white)));
    }

    public int getCurrentPageIndex() {
        if (contentPager != null) {
            return contentPager.getCurrentItem();
        } else {
            return 4;
        }
    }

    private void processIncomingCall() {
        Intent intent = new Intent(this, VoiceActivity.class);
        intent.setAction(VoiceActivity.ACTION_INCOMING_CALL);
        int notificationId = getIntent().getIntExtra(VoiceActivity.INCOMING_CALL_NOTIFICATION_ID, 0);
        intent.putExtra(VoiceActivity.INCOMING_CALL_NOTIFICATION_ID, notificationId);
        CallInvite callInvite = getIntent().getParcelableExtra(VoiceActivity.INCOMING_CALL_INVITE);
        intent.putExtra(VoiceActivity.INCOMING_CALL_INVITE, callInvite);
        this.startActivity(intent);
    }
}
