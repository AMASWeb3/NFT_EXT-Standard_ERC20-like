/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.utility.filechooser;

public interface OnContentSelectedListener {
    void onContentSelected(int fileType, Content content);

    void onError(Error error);
}
