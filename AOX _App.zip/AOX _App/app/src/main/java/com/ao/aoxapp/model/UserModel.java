/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.model;

import android.graphics.Bitmap;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UserModel {
    public static UserModel currentUser;

    public static final int AVATAR_SIZE = 256;

    public String userId;
    public String phoneNumber;
    public String firstName;
    public String lastName;
    public String ssidSsn;
    public String address;
    public String avatarURL;
    public String createdAt;
    public String token;

    public Bitmap avatar = null;
    public ArrayList<UserModel> contactsList = new ArrayList<>();
    public String keyForContact;

    public UserModel() {}

    public String getName() {
        String ret = firstName + " " + lastName;
        return ret;
    }

    public static void Register(UserModel mUserModel) {
        DatabaseReference mFirebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER);
        Map<String, String> map = new HashMap<String, String>();
        map.put(FirebaseConst.FIELD_USER_FIRSTNAME, mUserModel.firstName);
        map.put(FirebaseConst.FIELD_USER_LASTNAME, mUserModel.lastName);
        map.put(FirebaseConst.FIELD_USER_SSID_SSN, mUserModel.ssidSsn);
        map.put(FirebaseConst.FIELD_USER_PHONE_NUMBER, mUserModel.phoneNumber);
        map.put(FirebaseConst.FIELD_USER_ADDRESS, mUserModel.address);
        Date now = new Date();
        map.put(FirebaseConst.FIELD_USER_CREATEDAT, String.valueOf(now.getTime()));

        mFirebaseDBReference.child(mUserModel.userId).setValue(map);
    }

    public static int getIndexOfItem(ArrayList<UserModel> arrayList, UserModel model) {
        if (arrayList == null) {
            return -1;
        }
        if (arrayList.isEmpty()) {
            return -1;
        }
        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i).phoneNumber.equals(model.phoneNumber)) {
                return i;
            }
        }

        return -1;
    }

    public static UserModel getUserByPhoneNumber(ArrayList<UserModel> arrayList, String phoneNumber) {
        if (arrayList == null || arrayList.isEmpty()) {
            return null;
        }

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return null;
        }

        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i).phoneNumber != null &&
                arrayList.get(i).phoneNumber.equals(phoneNumber)) {
                return arrayList.get(i);
            }
        }

        return null;
    }

    public void getContacts(DataSnapshot dataSnapshot) {
        contactsList.clear();

        for (final DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
            try {
                final String userPhoneNumber = postSnapshot.getValue(String.class);
                final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(userPhoneNumber);
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        ref.removeEventListener(this);
                        try {
                            UserModel userModel = dataSnapshot.getValue(UserModel.class);
                            userModel.keyForContact = postSnapshot.getKey();
                            contactsList.add(userModel);
                        } catch (Exception e){}
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("The read failed: " + databaseError.getCode());
                    }
                });
            } catch (Exception e){}
        }
    }
}
