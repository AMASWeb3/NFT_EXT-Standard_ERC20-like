/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp;

public class AppConstant {
    //Live
    public static final String TWILLIO_ACCOUNT_SID = "AC7a07989ff926f676ec2104d362ad12e7";
    public static final String TWILLIO_AUTH_TOKEN  = "5196ac18a2e496b75d35f54e28635586";
    public static final String TWILLIO_PHONENUMBER  = "+18285284434";


    public static final String EK_TYPE = "TYPE";
    public static final String EK_OBJECTID = "OBJECTID";
    public static final String EK_USER_ID = "EK_USER_ID";

    public static final String EK_ROOMNAME = "EK_ROOMNAME";
    public static final String EK_USER_PHONENUMBER = "EK_USER_PHONENUMBER";
}
