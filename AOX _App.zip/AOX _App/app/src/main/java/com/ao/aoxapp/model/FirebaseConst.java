/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.model;

public class FirebaseConst {
    public static final String STORAGE_AVATAR = "Avatar";
    public static final String STORAGE_MESSAGE = "Message";

    public static final String TBL_USER = "Users";
    public static final String FIELD_USER_USERID = "userId";
    public static final String FIELD_USER_FIRSTNAME = "firstName";
    public static final String FIELD_USER_LASTNAME = "lastName";
    public static final String FIELD_USER_SSID_SSN= "ssidSsn";
    public static final String FIELD_USER_PHONE_NUMBER = "phoneNumber";
    public static final String FIELD_USER_ADDRESS = "address";
    public static final String FIELD_USER_PASSWORD = "password";
    public static final String FIELD_USER_AVATAR_URL = "avatarURL";
    public static final String FIELD_USER_CREATEDAT = "createdAt";
    public static final String FIELD_USER_CONTACTS = "contacts";
    public static final String FIELD_USER_TOKEN = "token";
}
