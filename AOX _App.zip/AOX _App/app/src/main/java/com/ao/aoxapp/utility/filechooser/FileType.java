/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.utility.filechooser;

public class FileType {
    public static final int TYPE_VIDEO = 1;
    public static final int TYPE_IMAGE = 2;
    public static final int TYPE_FILE = 3;
    public static final int TYPE_AUDIO = 4;
}
