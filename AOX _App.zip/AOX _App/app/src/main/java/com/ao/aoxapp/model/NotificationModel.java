/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.model;

import android.app.ActivityManager;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.ao.aoxapp.AOXApp;
import com.ao.aoxapp.AppConstant;
import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.push.RetrofitAPI;
import com.ao.aoxapp.ui.activity.BaseActivity;
import com.ao.aoxapp.ui.activity.MainActivity;
import com.ao.aoxapp.ui.activity.MessageActivity;
import com.ao.aoxapp.ui.activity.SplashActivity;
import com.ao.aoxapp.ui.activity.VideoCallActivity;
import com.ao.aoxapp.ui.activity.VoiceCallActivity;
import com.google.gson.annotations.SerializedName;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NotificationModel {
    public static int TYPE_MESSAGE              = 0;
    public static int TYPE_VIDEO_CALL_REQUEST   = 1;
    public static int TYPE_VIDEO_CALL_END       = 2;
    public static int TYPE_AUDIO_CALL_REQUEST   = 3;
    public static int TYPE_AUDIO_CALL_END       = 4;

    public static final String CHANNEL_ID = "aoxapp_channel_01";

    public int type;
    public int messageType;
    public String datetime;
    public String senderPhoneNumber;
    public String senderName;
    public String roomName;
    public String message;
    public String mediaUrl;

    public static class RequestNotificaton {
        @SerializedName("to") //  "to" changed to token
        public String to;
        @SerializedName("data")
        public NotificationModel data;
    }

    public static void sendMessageNotification(UserModel toUser, MessageModel messageModel) {
        NotificationModel notificationModel = new NotificationModel();
        notificationModel.type = TYPE_MESSAGE;
        notificationModel.messageType = messageModel.type;
        notificationModel.datetime = String.valueOf(new Date().getTime());
        notificationModel.senderPhoneNumber = UserModel.currentUser.phoneNumber;
        notificationModel.senderName = UserModel.currentUser.getName();
        notificationModel.roomName = "roomName";
        notificationModel.message = messageModel.message;
        notificationModel.mediaUrl = messageModel.photoFileUrl;

        String url = "https://fcm.googleapis.com/";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RequestNotificaton requestNotificaton = new RequestNotificaton();
        requestNotificaton.data = notificationModel;
        requestNotificaton.to = toUser.token;

        RetrofitAPI service = retrofit.create(RetrofitAPI.class);

        Call<ResponseBody> call = service.sendPushNotification(requestNotificaton);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.errorBody() != null) {
                        String error = response.errorBody().string();
                    }
                    if (response.body() != null) {
                        String res = response.body().string();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {}
        });
    }

    public static void sendVideoAudioCallNotification(UserModel toUser, boolean isVideo, String roomName) {
        NotificationModel notificationModel = new NotificationModel();
        if (isVideo) {
            notificationModel.type = TYPE_VIDEO_CALL_REQUEST;
            notificationModel.message = UserModel.currentUser.getName() + " is calling.";
        } else {
            notificationModel.type = TYPE_AUDIO_CALL_REQUEST;
            notificationModel.message = UserModel.currentUser.getName() + " is calling.";
        }
        notificationModel.messageType = MessageModel.TYPE_TEXT;
        notificationModel.mediaUrl = "";
        notificationModel.datetime = String.valueOf(new Date().getTime());
        notificationModel.senderPhoneNumber = UserModel.currentUser.phoneNumber;
        notificationModel.senderName = UserModel.currentUser.getName();
        notificationModel.roomName = roomName;

        String url = "https://fcm.googleapis.com/";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RequestNotificaton requestNotificaton = new RequestNotificaton();
        requestNotificaton.data = notificationModel;
        requestNotificaton.to = toUser.token;

        RetrofitAPI service = retrofit.create(RetrofitAPI.class);

        Call<ResponseBody> call = service.sendPushNotification(requestNotificaton);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.errorBody() != null) {
                        String error = response.errorBody().string();
                    }
                    if (response.body() != null) {
                        String res = response.body().string();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {}
        });
    }

    public static String foregroundActivityName(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
        ComponentName componentInfo = taskInfo.get(0).topActivity;
        return componentInfo.getClassName();
    }

    public static boolean isRunning(Context ctx) {
        ActivityManager activityManager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningTaskInfo> tasks = activityManager.getRunningTasks(Integer.MAX_VALUE);

        for (ActivityManager.RunningTaskInfo task : tasks) {
            if (ctx.getPackageName().equalsIgnoreCase(task.baseActivity.getPackageName()))
                return true;
        }

        return false;
    }

    public static void showNotification(final Context context, final NotificationModel notificationModel) {
        if (notificationModel == null)
            return;

        NotificationCompat.Builder notiBuilder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.drawable.noti_icon)
//                .setSmallIcon(R.drawable.health_noti_icon)
                .setContentTitle(context.getString(R.string.app_name))
                .setContentText(notificationModel.message)
//                .setContentTitle("Face Health Monitoring")
//                .setContentText("Tian Dong")
                .setChannelId(CHANNEL_ID)
                .setAutoCancel(true);

        RingtoneManager ringtoneMgr = new RingtoneManager(context);
        ringtoneMgr.getCursor();
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        notiBuilder.setSound(alarmSound);

        long[] pattern = {500};
        notiBuilder.setVibrate(pattern);

        Intent resultIntent = null;
        if (notificationModel.type == TYPE_MESSAGE) {
            resultIntent = new Intent(context, SplashActivity.class);
            resultIntent.putExtra(AppConstant.EK_TYPE, notificationModel.type);
            resultIntent.putExtra(AppConstant.EK_USER_ID, notificationModel.senderPhoneNumber);
            resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        } else if (notificationModel.type == TYPE_VIDEO_CALL_REQUEST) {
            resultIntent = new Intent(context, VideoCallActivity.class);
            resultIntent.putExtra(AppConstant.EK_ROOMNAME, notificationModel.roomName);
            resultIntent.putExtra(AppConstant.EK_USER_PHONENUMBER, notificationModel.senderPhoneNumber);
            resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        } else if (notificationModel.type == TYPE_AUDIO_CALL_REQUEST) {
            resultIntent = new Intent(context, VoiceCallActivity.class);
            resultIntent.putExtra(AppConstant.EK_ROOMNAME, notificationModel.roomName);
            resultIntent.putExtra(AppConstant.EK_USER_PHONENUMBER, notificationModel.senderPhoneNumber);
            resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }

        if (resultIntent != null) {
            PendingIntent resultPendingIntent = PendingIntent.getActivity(
                        context,
                        0,
                        resultIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);

            notiBuilder.setContentIntent(resultPendingIntent);
        }

        // show notification
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = null;
            CharSequence name = context.getString(R.string.channel_name);// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationManager.createNotificationChannel(mChannel);
        }

        if (notificationModel.type == NotificationModel.TYPE_MESSAGE) {
            MessageModel messageModel = new MessageModel();
            messageModel.type = notificationModel.messageType;
            messageModel.time = new Date().getTime();
            messageModel.message = notificationModel.message;
            messageModel.photoFileUrl = notificationModel.mediaUrl;
            messageModel.otherUserPhoneNumber = notificationModel.senderPhoneNumber;
            messageModel.senderUserPhoneNumber = notificationModel.senderPhoneNumber;
            messageModel.isOwnMessage = false;

            AppPreference appPreference = new AppPreference(context);
            ArrayList<MessageModel> allMessages = appPreference.getMessagesData();
            allMessages.add(messageModel);
            appPreference.setMesagesData(allMessages);

            if (foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MessageActivity")
                    && MessageActivity.instance != null ) {
                MessageActivity.instance.refresh();
            } else {
                notificationManager.notify(notificationModel.senderPhoneNumber, notificationModel.type, notiBuilder.build());
            }

            if (foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MainActivity")
                    && MainActivity.instance != null
                    && MainActivity.instance.getCurrentPageIndex() == 0 && MainActivity.instance.contactsFragment != null) {
                MainActivity.instance.contactsFragment.refreshListView();
            }
        } else if (notificationModel.type == NotificationModel.TYPE_VIDEO_CALL_REQUEST || notificationModel.type == NotificationModel.TYPE_AUDIO_CALL_REQUEST) {
            if (foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MainActivity") || foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MessageActivity")) {
                BaseActivity activity = null;
                if (foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MainActivity") && MainActivity.instance != null) {
                    activity = MainActivity.instance;
                } else if (foregroundActivityName(context).equals("com.ao.aoxapp.ui.activity.MessageActivity") && MessageActivity.instance != null) {
                    activity = MessageActivity.instance;
                }

                if (activity != null) {
                    final BaseActivity baseActivity = activity;
                    baseActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            final Dialog dialog = new Dialog(baseActivity);
                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialog.setContentView(R.layout.dialog_incoming_video_call);
                            dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
                            TextView title = (TextView) dialog.findViewById(R.id.txt_title);
                            TextView message = (TextView) dialog.findViewById(R.id.txt_message);
                            TextView accept = (TextView) dialog.findViewById(R.id.btn_left);
                            TextView reject = (TextView) dialog.findViewById(R.id.btn_right);
                            title.setText(baseActivity.getResources().getString(R.string.incoming_call));
                            message.setText(notificationModel.message);
                            accept.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();

                                    if (notificationModel.type == NotificationModel.TYPE_VIDEO_CALL_REQUEST) {
                                        Intent intent = new Intent(baseActivity, VideoCallActivity.class);
                                        intent.putExtra(AppConstant.EK_ROOMNAME, notificationModel.roomName);
                                        intent.putExtra(AppConstant.EK_USER_PHONENUMBER, notificationModel.senderPhoneNumber);
                                        AOXApp.getContext().startActivity(intent);
                                    } else {
                                        Intent intent = new Intent(baseActivity, VoiceCallActivity.class);
                                        intent.putExtra(AppConstant.EK_ROOMNAME, notificationModel.roomName);
                                        intent.putExtra(AppConstant.EK_USER_PHONENUMBER, notificationModel.senderPhoneNumber);
                                        AOXApp.getContext().startActivity(intent);
                                    }
                                }
                            });

                            reject.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });

                            dialog.show();
                        }
                    });
                }
            } else {
                notificationManager.notify(notificationModel.senderPhoneNumber, notificationModel.type, notiBuilder.build());
            }
        }
    }
}
