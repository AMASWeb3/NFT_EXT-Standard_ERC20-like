/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.utility.swipelist.adapter;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.model.MessageModel;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.ui.fragment.ContactsFragment;
import com.ao.aoxapp.utility.MyImageLoader;
import com.ao.aoxapp.utility.swipelist.widget.SwipeListView;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.ao.aoxapp.utility.MyImageLoader.TYPE_NORMAL;

public class SwipeAdapter extends ArrayAdapter<UserModel> {
    private Context mContext = null;
    private int mRightWidth = 0;
    private SwipeListView mListView;
    private ContactsFragment contactsFragment;

    private ArrayList<UserModel> mData;

    public void setData(ArrayList<UserModel> data) {
        mData = data;
    }
    public ArrayList<UserModel> getData() {
        return mData;
    }

    public SwipeAdapter(Context ctx, int rightWidth, SwipeListView listView, ContactsFragment contactsFragment) {
        super(ctx, 0);
        mContext = ctx;
        mRightWidth = rightWidth;
        mListView = listView;
        this.contactsFragment = contactsFragment;
    }

    public UserModel getItem(int position) {
        return mData.get(position);
    }

    @Override
    public int getCount() {
        if (mData == null) {
            return 0;
        }
        return mData.size();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder item;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.list_item_messages, parent, false);
            item = new ViewHolder();
            item.item_left = convertView.findViewById(R.id.item_left);
            item.item_right = convertView.findViewById(R.id.item_right);
            item.item_right_del = convertView.findViewById(R.id.txt_delete);
            item.img_photo = convertView.findViewById(R.id.img_photo);
            item.loadingBar = convertView.findViewById(R.id.progress_file);
            item.txt_name = convertView.findViewById(R.id.txt_name);
            item.txt_time = convertView.findViewById(R.id.txt_time);
            item.txt_message = convertView.findViewById(R.id.txt_message);

            convertView.setTag(item);
        } else {
            item = (ViewHolder)convertView.getTag();
        }
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        item.item_left.setLayoutParams(lp1);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(mRightWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        item.item_right.setLayoutParams(lp2);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(mRightWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        item.item_right_del.setLayoutParams(lp3);

        final UserModel contact = getItem(position);
        item.txt_name.setText(contact.getName());
        String thumbnail = contact.avatarURL;
        if (thumbnail != null && !thumbnail.isEmpty()) {
            item.loadingBar.setVisibility(View.VISIBLE);
            MyImageLoader.showAvatar(item.img_photo, thumbnail, TYPE_NORMAL, new SimpleImageLoadingListener(){
                public void onLoadingStarted(String imageUri, View view) {}
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { item.loadingBar.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { item.loadingBar.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { item.loadingBar.setVisibility(View.GONE); }
            });
        } else {
            item.img_photo.setImageResource(R.drawable.ic_default_user_avatar_blue);
            item.loadingBar.setVisibility(View.GONE);
        }

        AppPreference appPreference = new AppPreference(contactsFragment.mainActivity);
        MessageModel lastMessage = appPreference.getLastMessage(contact.phoneNumber);
        if (lastMessage != null) {
            item.txt_message.setText(lastMessage.message);
            Date now = new Date();
            Date latestTime = new Date(lastMessage.time);

            if (now.getYear() == latestTime.getYear() && now.getMonth()==latestTime.getMonth() && now.getDay()==latestTime.getDay()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
                String strDate = dateFormat.format(latestTime);
                item.txt_time.setText(strDate);
            } else if (now.getYear() == latestTime.getYear() && now.getMonth()==latestTime.getMonth() && now.getDay()==latestTime.getDay() + 1) {
                item.txt_time.setText("Yesterday");
            } else {
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMMM dd, yyyy");
                String strDate = dateFormat.format(latestTime);
                item.txt_time.setText(strDate);
            }
        } else {
            item.txt_message.setText("");
            item.txt_time.setText("");
        }

        item.item_right_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(mContext);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.dialog_layout);
                dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
                TextView title = (TextView) dialog.findViewById(R.id.txt_title);
                TextView message = (TextView) dialog.findViewById(R.id.txt_message);
                TextView left = (TextView) dialog.findViewById(R.id.btn_left);
                TextView right = (TextView) dialog.findViewById(R.id.btn_right);
                title.setText(contactsFragment.mainActivity.getResources().getString(R.string.delete));
                message.setText(contactsFragment.mainActivity.getResources().getString(R.string.delete_friend_message1));
                left.setText(contactsFragment.mainActivity.getResources().getString(R.string.YES));
                right.setText(contactsFragment.mainActivity.getResources().getString(R.string.NO));
                left.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (contactsFragment != null) {
                            contactsFragment.deleteContact(contact, position);
                        }

                        if (mListView != null) {
                            mListView.anyHiddenRight();
                        }

                        dialog.dismiss();
                    }
                });

                right.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mListView != null) {
                            mListView.anyHiddenRight();
                        }

                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        return convertView;
    }

    private class ViewHolder {
        View item_left;
        View item_right;
        TextView item_right_del;
        CircleImageView img_photo;
        ProgressBar loadingBar;
        TextView txt_name;
        TextView txt_time;
        TextView txt_message;
    }
}
