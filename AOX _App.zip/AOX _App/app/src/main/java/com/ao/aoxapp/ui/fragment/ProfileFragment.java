/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.fragment.app.Fragment;

import com.ao.aoxapp.R;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.ui.activity.LoginActivity;
import com.ao.aoxapp.ui.activity.MainActivity;
import com.ao.aoxapp.utility.CommonUtil;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.ao.aoxapp.utility.MyImageLoader;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;

import static com.ao.aoxapp.utility.MyImageLoader.TYPE_NORMAL;

public class ProfileFragment extends Fragment {
    private MainActivity mainActivity;
    private View mView = null;

    @BindView(R.id.img_profile)
    CircleImageView img_profile;
    @BindView(R.id.progress_file)
    ProgressBar progress_file;

    @BindView(R.id.txt_firstName)
    EditText txt_firstName;

    @BindView(R.id.txt_lastName)
    EditText txt_lastName;

    @BindView(R.id.txt_ssid)
    EditText txt_ssid;

    @BindView(R.id.txt_phoneNumber)
    EditText txt_phoneNumber;

    @BindView(R.id.txt_location)
    EditText txt_location;

    public void setMainActivity(MainActivity activity) { mainActivity = activity; }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_profile, container, false);
        ButterKnife.bind(this, mView);
        mainActivity = (MainActivity) getActivity();
        return mView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mainActivity = MainActivity.instance;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mView == null)
            return;

        init();
    }

    private void init() {
        if (UserModel.currentUser == null || UserModel.currentUser.phoneNumber == null) {
            Intent intent = new Intent(mainActivity, LoginActivity.class);
            mainActivity.startActivity(intent);
            mainActivity.overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
            mainActivity.finish();
        }

        txt_firstName.setText(UserModel.currentUser.firstName);
        txt_lastName.setText(UserModel.currentUser.lastName);
        txt_phoneNumber.setText(UserModel.currentUser.phoneNumber);
        txt_location.setText(UserModel.currentUser.address);
        txt_ssid.setText(UserModel.currentUser.ssidSsn);
        String thumbnail = UserModel.currentUser.avatarURL;
        if (thumbnail != null && !thumbnail.isEmpty()) {
            progress_file.setVisibility(View.VISIBLE);
            MyImageLoader.showAvatar(img_profile, thumbnail, TYPE_NORMAL, new SimpleImageLoadingListener() {
                public void onLoadingStarted(String imageUri, View view) { }
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { progress_file.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { progress_file.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { progress_file.setVisibility(View.GONE); }
            });
        } else {
            img_profile.setImageResource(R.drawable.ic_default_user_avatar_green);
            progress_file.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.btn_save)
    public void onSave() {
        CommonUtil.hideKeyboard(mainActivity, txt_firstName);

        if (!DeviceUtil.isNetworkAvailable(mainActivity)) {
            return;
        }
        if (isValid()) {
            save();
        }
    }

    private boolean isValid() {
        if (TextUtils.isEmpty(txt_firstName.getText().toString().trim())) {
            MessageUtil.showError(mainActivity, R.string.enter_first_name);
            return false;
        }
        if (txt_firstName.getText().toString().trim().length() > 20) {
            MessageUtil.showError(mainActivity, R.string.firstname_long);
            return false;
        }

        if (TextUtils.isEmpty(txt_lastName.getText().toString().trim())) {
            MessageUtil.showError(mainActivity, R.string.enter_lastname);
            return false;
        }
        if (txt_lastName.getText().toString().trim().length() > 20) {
            MessageUtil.showError(mainActivity, R.string.lastname_long);
            return false;
        }
        if (TextUtils.isEmpty(txt_phoneNumber.getText().toString().trim())) {
            MessageUtil.showError(mainActivity, R.string.enter_cell_number);
            return false;
        }
        if (TextUtils.isEmpty(txt_location.getText().toString().trim())) {
            MessageUtil.showError(mainActivity, R.string.enter_address);
            return false;
        }

        return true;
    }

    private void save() {
        UserModel.currentUser.firstName = txt_firstName.getText().toString().trim();
        UserModel.currentUser.lastName = txt_lastName.getText().toString().trim();
        UserModel.currentUser.phoneNumber = txt_phoneNumber.getText().toString().trim();
        UserModel.currentUser.address = txt_location.getText().toString().trim();
        UserModel.currentUser.ssidSsn = txt_ssid.getText().toString().trim();

        DatabaseReference mFirebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(UserModel.currentUser.phoneNumber);
        mFirebaseDBReference.child(FirebaseConst.FIELD_USER_FIRSTNAME).setValue(txt_firstName.getText().toString().trim());
        mFirebaseDBReference.child(FirebaseConst.FIELD_USER_LASTNAME).setValue(txt_lastName.getText().toString().trim());
        mFirebaseDBReference.child(FirebaseConst.FIELD_USER_PHONE_NUMBER).setValue(txt_phoneNumber.getText().toString().trim());
        mFirebaseDBReference.child(FirebaseConst.FIELD_USER_ADDRESS).setValue(txt_location.getText().toString().trim());
        mFirebaseDBReference.child(FirebaseConst.FIELD_USER_SSID_SSN).setValue(txt_ssid.getText().toString().trim());

        MessageUtil.showAlertDialog(mainActivity, MessageUtil.TYPE_SUCCESS, R.string.profile_is_updated);
    }
}
