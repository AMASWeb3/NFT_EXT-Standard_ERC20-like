/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.utility.CommonUtil;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.ao.aoxapp.utility.PermissionUtils;
import com.ao.aoxapp.utility.ResourceUtil;
import com.ao.aoxapp.utility.filechooser.Content;
import com.ao.aoxapp.utility.filechooser.Error;
import com.ao.aoxapp.utility.filechooser.FileChooser;
import com.ao.aoxapp.utility.filechooser.FileType;
import com.ao.aoxapp.utility.filechooser.OnContentSelectedListener;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;

import static com.ao.aoxapp.AppPreference.KEY.FCM_TOKEN;

public class SignUpActivity extends BaseActivity implements OnContentSelectedListener {
    public static SignUpActivity instance;

    @BindView(R.id.img_profile)
    CircleImageView img_profile;

    @BindView(R.id.txt_firstName)
    EditText txt_firstName;

    @BindView(R.id.txt_lastName)
    EditText txt_lastName;

    @BindView(R.id.txt_ssid)
    EditText txt_ssid;

    @BindView(R.id.txt_phoneNumber)
    EditText txt_phoneNumber;

    @BindView(R.id.txt_location)
    EditText txt_location;

    private UserModel mUserModel;
    private boolean isPhotoAdded = false;
    private Bitmap mOrgBmp = null;
    private String mAvatarDownloadURL = "";
    private FileChooser fileChooser;

    private DatabaseReference mFirebaseDBReference;
    private StorageReference mFirebaseStorageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ButterKnife.bind(this);
        instance = this;
    }

    @Override
    protected void onResume() {
        super.onResume();
        instance = this;

        fileChooser = new FileChooser(this);
    }

    @Override
    protected void onPause() {
        CommonUtil.hideKeyboard(this, txt_firstName);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        onBack();
    }

    @OnClick(R.id.btn_back)
    public void onBack() {
        CommonUtil.hideKeyboard(this, txt_firstName);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
    }

    @OnClick(R.id.btn_next)
    public void onNext() {
        if (!DeviceUtil.isNetworkAvailable(this)) {
            return;
        }

        CommonUtil.hideKeyboard(instance, txt_firstName);
        if (isValid()) {
            register();
        }
    }

    private boolean isValid() {
        if (TextUtils.isEmpty(txt_firstName.getText().toString().trim())) {
            MessageUtil.showError(instance, R.string.enter_first_name);
            return false;
        }
        if (txt_firstName.getText().toString().trim().length() > 20) {
            MessageUtil.showError(instance, R.string.firstname_long);
            return false;
        }

        if (TextUtils.isEmpty(txt_lastName.getText().toString().trim())) {
            MessageUtil.showError(instance, R.string.enter_lastname);
            return false;
        }
        if (txt_lastName.getText().toString().trim().length() > 20) {
            MessageUtil.showError(instance, R.string.lastname_long);
            return false;
        }

        if (TextUtils.isEmpty(txt_ssid.getText().toString().trim())) {
            MessageUtil.showError(instance, R.string.enter_ssid_ssn);
            return false;
        }

        if (TextUtils.isEmpty(txt_phoneNumber.getText().toString().trim())) {
            MessageUtil.showError(instance, R.string.enter_cell_number);
            return false;
        }
        if (TextUtils.isEmpty(txt_location.getText().toString().trim())) {
            MessageUtil.showError(instance, R.string.enter_address);
            return false;
        }

        if (!isPhotoAdded) {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_layout);
            dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
            TextView title = (TextView) dialog.findViewById(R.id.txt_title);
            TextView message = (TextView) dialog.findViewById(R.id.txt_message);
            TextView left = (TextView) dialog.findViewById(R.id.btn_left);
            TextView right = (TextView) dialog.findViewById(R.id.btn_right);
            title.setText(getResources().getString(R.string.profile_photo));
            message.setText(getResources().getString(R.string.valid_confirm_avatar));
            left.setText(getResources().getString(R.string.YES));
            right.setText(getResources().getString(R.string.UPLOAD_PHOTO));
            left.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    if (!DeviceUtil.isNetworkAvailable(instance)) {
                        return;
                    }
                    register();
                }
            });
            right.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    showPhotoDialog();
                }
            });

            dialog.show();
            return false;
        }

        return true;
    }

    @OnClick(R.id.img_profile)
    public void onSetProfileImage() {
        showPhotoDialog();
    }

    private void showPhotoDialog() {
        new AlertDialog.Builder(instance)
                .setTitle(R.string.upload_photo)
                .setPositiveButton(R.string.select_gallery, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (PermissionUtils.checkPermissionForExternalStorage(instance)) {
                            chooseTakePhoto(false);
                        } else {
                            PermissionUtils.requestPermissionForExternalStorage(instance);
//                            MessageUtil.showError(instance, R.string.msg_error_permission_storage);
                        }
                    }
                })
                .setNegativeButton(R.string.take_new_photo, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (PermissionUtils.checkPermissionForCamera(instance)) {
                            if (PermissionUtils.checkPermissionForExternalStorage(instance)) {
                                chooseTakePhoto(true);
                            } else {
                                PermissionUtils.requestPermissionForExternalStorage(instance);
//                                MessageUtil.showError(instance, R.string.msg_error_permission_storage);
                            }
                        } else {
                            PermissionUtils.requestPermissionForCamera(instance);
//                            MessageUtil.showError(instance, R.string.msg_error_permission_camera);
                        }
                    }
                })
                .show();
    }

    // choose photo and take
    private void chooseTakePhoto(boolean isTake) {
        if (!isTake) {
            fileChooser.getImage(this, true);
        } else {
            fileChooser.takePhoto(this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (fileChooser != null)
            fileChooser.onActivityResult(requestCode, resultCode, data);
        else {
            fileChooser = new FileChooser(this);
            MessageUtil.showError(this, R.string.permission_changed);
            return;
        }
    }

    // register
    private void register() {
        showProgressDialog();

        mUserModel = new UserModel();
        mUserModel.userId = txt_phoneNumber.getText().toString().trim();
        mUserModel.firstName = txt_firstName.getText().toString().trim();
        mUserModel.lastName = txt_lastName.getText().toString().trim();
        mUserModel.phoneNumber = txt_phoneNumber.getText().toString().trim();
        mUserModel.address = txt_location.getText().toString().trim();
        mUserModel.token = AppPreference.getStr(FCM_TOKEN, "");
        mUserModel.ssidSsn = txt_ssid.getText().toString();

        UserModel.Register(mUserModel);

        uploadProfilePhoto();
    }

    private void uploadProfilePhoto() {
        if (mOrgBmp != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            mOrgBmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();

            FirebaseStorage storage = FirebaseStorage.getInstance();
            mFirebaseStorageReference = storage.getReference().child(FirebaseConst.STORAGE_AVATAR).child(mUserModel.phoneNumber);
            mFirebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER);
            UploadTask uploadTask = mFirebaseStorageReference.putBytes(data);
            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    return mFirebaseStorageReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    hidProgressDialog();
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        mAvatarDownloadURL = downloadUri.toString();
                        mFirebaseDBReference.child(txt_phoneNumber.getText().toString().trim()).child(FirebaseConst.FIELD_USER_AVATAR_URL).setValue(mAvatarDownloadURL);
                        gotoMainActivity();
                    } else {
                        MessageUtil.showError(instance, R.string.msg_error_network);
                    }
                }
            });
        } else {
            hidProgressDialog();
            gotoMainActivity();
        }
    }

    private void gotoMainActivity() {
        AppPreference.setBool(AppPreference.KEY.SIGN_IN_AUTO, true);
        AppPreference.setStr(AppPreference.KEY.SIGN_IN_USERNAME, mUserModel.phoneNumber);

        UserModel.currentUser = mUserModel;
        UserModel.currentUser.avatarURL = mAvatarDownloadURL;
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fileChooser != null)
            fileChooser.release();
    }

    @Override
    public void onContentSelected(int fileType, Content content) {
        if (fileType == FileType.TYPE_IMAGE) {
            if (mOrgBmp != null)
                mOrgBmp.recycle();
            mOrgBmp = content.getBitmap();
            img_profile.setImageBitmap(mOrgBmp);

            String filePath = ResourceUtil.getAvatarFilePath();
            ResourceUtil.saveBitmapToSdcard(mOrgBmp, filePath);
            mOrgBmp = ResourceUtil.decodeSampledBitmapFromFile(filePath, UserModel.AVATAR_SIZE);

            isPhotoAdded = true;
        } else {
            MessageUtil.showError(this, R.string.choose_image);
        }
    }

    @Override
    public void onError(Error error) {
        if (error.getType() == Error.NULL_PATH_ERROR) {
        } else {
            Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
